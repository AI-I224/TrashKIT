/*****************************************************************************
 ____  _____ _        _
| __ )| ____| |      / \
|  _ \|  _| | |     / _ \
| |_) | |___| |___ / ___ \
|____/|_____|_____/_/   \_\
http://bela.io

Bela-Arduino TrashKit project
Physical Computing (Gizmo) 2024
Bela.io / Imperial College London

render.cpp: this file is for code in the Arduino (Wiring) language

Author: Andrew Ize-Iyamu
Date: 2024-11-26

*****************************************************************************

References:

*****************************************************************************
*    Title: Bela: Communication/OSC/render.cpp
*    Author: Bela.io
*    Date: 2016
*    Code version: N/A
*    Availability: https://docs.bela.io/Communication_2OSC_2render_8cpp-example.html
****************************************************************************/

// Load in necessary libraries
#include <Bela.h>
#include <libraries/BelaLibpd/BelaLibpd.h>
#include <libraries/BelaArduino/BelaArduino.h>
#include <libraries/OscSender/OscSender.h>
#include <libraries/OscReceiver/OscReceiver.h>
#include <libraries/Watcher/Watcher.h>

// Used the template provided by resources to set up OSC reciever 
// communication for the Bela

// These lines set up a GUI (Watcher) to monitor the values of variables
WatcherManager& wm = *Bela_getDefaultWatcherManager();

// Define variable for OscReciever
OscReceiver oscReceiver;

// Define local port for Bela to listen from
int localPort = 7562;

// Define variable that holds ID for gesture
int gHandGestureId = 0;

// parse messages received by the OSC receiver
// msg is Message class of oscpkt: http://gruntthepeon.free.fr/oscpkt/
bool handshakeReceived;
void on_receive(oscpkt::Message* msg, const char* addr, void* arg)
{
	printf("From %s\n", addr);
	// Debugging test to check OSC set up properly
	if(msg->match("/osc-setup-reply"))
		handshakeReceived = true;

	// Follows storage logic when corrrect message type is sent 
	else if(msg->match("/osc-test")){
		int intArg;
		float floatArg;
		// Saves numbers sent as integer and float variables
		msg->match("/osc-test").popInt32(intArg).popFloat(floatArg).isOkNoMoreArgs();
		// Debugging print to check if the correct OSC message was recieved
		printf("received Gesture ID of %i\n", intArg);
		// Stores recieved gesture ID in global variable
		gHandGestureId = intArg;
	}
}

bool setup(BelaContext *context, void *userData)
{
	// Sets up the local port for recieving OSC messages
	oscReceiver.setup(localPort, on_receive);
	
	// Initialise the Pd audio environment, which runs the patch 
	// _main.pd within the project folder
	BelaLibpdSettings settings;
	settings.useIoThreaded = false;
	settings.useGui = false; // we want to use the BelaArduino GUI, which is controlled here and in ino.cpp
	settings.messageHook = BelaArduino_messageHook;
	settings.listHook = BelaArduino_listHook;
	settings.floatHook = BelaArduino_floatHook;
	if(!BelaLibpd_setup(context, userData, settings))
		return false;
		
	// Initialise the Arduino environment which runs in ino.cpp
	BelaArduinoSettings arduinoSettings {};
	if(!BelaArduino_setup(context, userData, arduinoSettings))
		return false;
		
	// Initialise the Watcher which lets us observe the values of
	// variables defined with Watcher<> -- see "myvar" example above
	unsigned int wsPort = 5557;
	wm.getGui().setup("/libraries/Watcher/sketch-watcher-example.js", wsPort);
	wm.setup(context->audioSampleRate);
	printf("sketch-watcher.js GUI at bela.local/gui?wsPort=%u\n", wsPort);
	
	// Return true to indicate setup succeeded (false will stop the program)
	return true;
}

void render(BelaContext *context, void *userData)
{
	// Manage the Watcher: this line needed to tell it an audio block has occurred
	if(wm.getGui().numConnections())
		wm.tick(context->audioFramesElapsed);
		
	// Run the Arduino and Pd code
	BelaArduino_renderTop(context, userData);
	BelaLibpd_render(context, userData);
	
	// ---
	// Your custom render() code should go here
	// ---
	
	BelaArduino_renderBottom(context, userData);
}

void cleanup(BelaContext *context, void *userData)
{
	BelaArduino_cleanup(context, userData);
	BelaLibpd_cleanup(context, userData);
}
