/*****************************************************************************

 ____  _____ _        _
| __ )| ____| |      / \
|  _ \|  _| | |     / _ \
| |_) | |___| |___ / ___ \
|____/|_____|_____/_/   \_\
http://bela.io

Bela-Arduino TrashKit project
Physical Computing (Gizmo) 2024
Bela.io / Imperial College London

ino.cpp: this file is for code in the Arduino (Wiring) language

Author: Andrew Ize-Iyamu
Date: 2024-11-26

*****************************************************************************/

#include <libraries/BelaArduino/Arduino.h>
#include <libraries/BelaArduino/PdArduino.h>
#include <libraries/Watcher/Watcher.h>

// Gesture ID
extern int gHandGestureId; // Imports gesture ID from render.cpp
int prevgHandGestureId; // Stores previous gesture ID to maintain steady state

// Event Definitions

unsigned int lastTime1 = 0; // When the first sound last occurred
unsigned int lastTime2 = 0; // When the second sound last occurred
unsigned int lastTime3 = 0; // When the third sound last occurred
unsigned int lastTime4 = 0; // When the fourth sound last occurred
unsigned int lastTime5 = 0; // When the first sound last occurred
unsigned int lastTime6 = 0; // When the second sound last occurred
unsigned int lastTime7 = 0; // When the third sound last occurred
unsigned int lastTime8 = 0; // When the fourth sound last occurred
unsigned int lastTime9 = 0; // When the first sound last occurred
unsigned int lastTime10 = 0; // When the second sound last occurred
unsigned int lastTime11 = 0; // When the third sound last occurred
unsigned int lastTime12 = 0; // When the fourth sound last occurred
unsigned int lastTimeM1 = 0; // When mechanism 1 last occurred (lastTime5)
unsigned int lastTimeM2 = 0; // When mechanism 2 last occurred (lastTime6)
unsigned int lastTimeM3 = 0; // When mechanism 3 last occurred (lastTime7)
unsigned int lastTimeM4 = 0; // When mechanism 4 last occurred (lastTime8)
unsigned int lastTimeM5 = 0; // When mechanism 5 last occurred (lastTime9)

// Pin Definitions

int kMotorPin1 = 1;
int kMotorPin2 = 0; // Pins for DC motor controlling Right-hand Tropical Crush can
int kMotorState = LOW; // Start with motor pins LOW

int tMotorPin1 = 2;
int tMotorPin2 = 3;  // Pins for DC motor controlling Left-hand Tropical Crush can
int tMotorState = LOW; // Start with motor pins LOW

int sMotorPin1 = 7;
int sMotorPin2 = 6;  // Pins for DC motor controlling shoe mechanism
int sMotorState = LOW; // Start with motor pins LOW

const int motorPins1[4] = {12, 13, 14, 15}; // Pins for stepper motor controlling minute hand
const int motorPins2[4] = {8, 9, 10, 11}; // Pins for stepper motor controlling hour hand

// Special variables for controlling DC and Stepper motors

float gCurrentDutyCycle = 0.0; // Current duty cycle of DC motors
bool gDutyCycleIsIncreasing = true; // State for whether DC motors are accelerating or decelerating
float speed; // Speed of DC motors

bool swap = false; // Controlling direction of stepper motors

// Audio Variables

bool audiopause1 = false;
bool audiopause2 = false;
bool audiopause3 = false;
bool audiopause4 = false;
bool audiopause5 = false;
bool audiopause6 = false;
bool audiopause7 = false;
bool audiopause8 = false;
bool audiopause9 = false;

// This controls the number of steps per cycle in State 3
const float kDutyCycleIncrement = 0.01;

// Sequence Definitions

int currentStep1 = 0; // Current step in the sequence for minute hand in clock
int currentStep2 = 0; // Current step in the sequence for hour hand in clock

// Step sequence to control the stepper motors to go clockwise
const int stepSequence1[8][4] = {
  {1, 0, 0, 0},
  {1, 1, 0, 0},
  {0, 1, 0, 0},
  {0, 1, 1, 0},
  {0, 0, 1, 0},
  {0, 0, 1, 1},
  {0, 0, 0, 1},
  {1, 0, 0, 1}
};

// Step sequence to control the stepper motors to go anti-clockwise
const int stepSequence2[8][4] = {
  {0, 0, 0, 1},
  {0, 0, 1, 1},
  {0, 0, 1, 0},
  {0, 1, 1, 0},
  {0, 1, 0, 0},
  {1, 1, 0, 0},
  {1, 0, 0, 0},
  {1, 0, 0, 1}
};

// This function runs once at the beginning
void setup()
{
	
	// Right-hand can DC motor setup
	pinMode(kMotorPin1, OUTPUT);
	pinMode(kMotorPin2, OUTPUT);
    
    // Left-hand can DC motor setup
    pinMode(tMotorPin1, OUTPUT);
	pinMode(tMotorPin2, OUTPUT);
	
	// Shoe mechanism DC motor setup
    pinMode(sMotorPin1, OUTPUT);
	pinMode(sMotorPin2, OUTPUT);
    
    // Start with all stepper pins LOW
    for (int i = 0; i < 4; i++) {
    pinMode(motorPins1[i], OUTPUT);
    digitalWrite(motorPins1[i], LOW);
    }
    for (int i = 0; i < 4; i++) {
    pinMode(motorPins2[i], OUTPUT);
    digitalWrite(motorPins2[i], LOW);
    }
	
	// Load drum sounds
	pdSendMessage("loadSound", 1, "crash.wav"); 
	pdSendMessage("loadSound", 2, "hihat.wav");
	pdSendMessage("loadSound", 3, "snare.wav");
	pdSendMessage("loadSound", 4, "kick.wav");
}

// This function runs in a loop, forever
void loop()
{
	if (gHandGestureId == 1) {
		// Closed Fist: Stops all motion in the trash kit
		unsigned int now = millis();
		if(now - lastTimeM1 > 100) {
			// Turn off all DC motors
			kMotorState = LOW;
			pwmWrite(kMotorPin1, 0);
			digitalWrite(kMotorPin2, kMotorState);
			tMotorState = LOW;
			pwmWrite(tMotorPin1, 0);
			digitalWrite(tMotorPin2, tMotorState);
			sMotorState = LOW;
			pwmWrite(sMotorPin1, 0);
			digitalWrite(sMotorPin2, sMotorState);
			// Reset state
			lastTimeM1 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 1;
	}
	else if (gHandGestureId == 2) {
		// Open Palm: Enters base state for trash kit
		unsigned int now = millis();
		if(now - lastTime1 > 100 && audiopause1 == false) {
			// Play first sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause1 = true;
		}
		else if(now - lastTime2 > 500 && audiopause2 == false) {
			// Play second sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause2 = true;
		}
		else if(now - lastTime3 > 700 && audiopause3 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause3 = true;
		}
		else if(now - lastTime4 > 1100 && audiopause4 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause4 = true;
		}
		else if(now - lastTime5 > 1300 && audiopause5 == false) {
			// Play fourth sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause5 = true;
		}
		else if(now - lastTime6 > 1600 && audiopause6 == false) {
			// Play fifth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause6 = true;
		}
		else if(now - lastTime7 > 1800 && audiopause7 == false) {
			// Play sixth sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause7 = true;
		}
		else if(now - lastTime8 > 2200 && audiopause7 == false) {
			// Play seventh sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause8 = true;
		}
		else if(now - lastTime9 > 2300 && audiopause1 == true) {
			// Play eighth sound & reset sound sequence
			lastTime9 = now;
			lastTime8 = now;
			lastTime7 = now;
			lastTime6 = now;
			lastTime5 = now;
			lastTime4 = now;
			lastTime3 = now;
			lastTime2 = now;
			lastTime1 = now;
			// Resets pauses for sounds
			audiopause1 = false;
			audiopause2 = false;
			audiopause3 = false;
			audiopause4 = false;
			audiopause5 = false;
			audiopause6 = false;
			audiopause7 = false;
		}
		else if(now - lastTimeM1 > 1) {
			// Start Right-hand can motor
			kMotorState = !kMotorState;
			pwmWrite(kMotorPin1, 0.8);
			digitalWrite(kMotorPin2, kMotorState);
			// Start Left-hand can motor
			tMotorState = !tMotorState;
			pwmWrite(tMotorPin1, 0.8);
			digitalWrite(tMotorPin2, tMotorState);
			// Start Shoe can motor
			sMotorState = !sMotorState;
			pwmWrite(sMotorPin1, 0.9);
			digitalWrite(sMotorPin2, sMotorState);
			// Start minute and hour hand motors
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence1[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence1[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM1 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 2;
	}
	else if (gHandGestureId == 3) {
		// Pointing Up: Increases and decreases speeds of can mechanisms,
		// and switches direction of clock hands back and forth for trash kit
		unsigned int now = millis();
		if(now - lastTime1 > 1000*speed && audiopause1 == false) {
			// Play first sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause1 = true;
		}
		else if(now - lastTime2 > 6000*speed && audiopause2 == false) {
			// Play second sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause2 = true;
		}
		else if(now - lastTime3 > 8500*speed && audiopause3 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause3 = true;
		}
		else if(now - lastTime4 > 13500*speed && audiopause4 == false) {
			// Play fourth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause4 = true;
		}
		else if(now - lastTime5 > 16000*speed && audiopause5 == false) {
			// Play fifth sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause5 = true;
		}
		else if(now - lastTime6 > 17500*speed && audiopause1 == true) {
			// Play sixth sound & reset sound sequence
			lastTime6 = now;
			lastTime5 = now;
			lastTime4 = now;
			lastTime3 = now;
			lastTime2 = now;
			lastTime1 = now;
			// Resets pauses for sounds
			audiopause1 = false;
			audiopause2 = false;
			audiopause3 = false;
			audiopause4 = false;
			audiopause5 = false;
			audiopause6 = false;
			audiopause7 = false;
			// Change direction of stepper motor
			swap =! swap;
		}
		else if(now - lastTimeM1 > 100*speed) {
			// Start Right-hand can motor
			digitalWrite(kMotorPin2, LOW);
		    pwmWrite(kMotorPin1, gCurrentDutyCycle);
		    // Start Left-hand can motor
		    digitalWrite(tMotorPin2, LOW);
		    pwmWrite(tMotorPin1, gCurrentDutyCycle);
		    // Start Shoe motor
		    digitalWrite(sMotorPin2, LOW);
		    pwmWrite(sMotorPin1, gCurrentDutyCycle);
		    // Control sequence for increasing and decreasing motor speeds
		    if(gDutyCycleIsIncreasing) {
		    	// Increment the speed of the motors
		        gCurrentDutyCycle += kDutyCycleIncrement;
		        if(gCurrentDutyCycle >= 1.0) {
		            gCurrentDutyCycle = 1.0;
		            // Change acceleration of motors
		            gDutyCycleIsIncreasing = false;
		        }
		    }
		    else {
		    	// Decrement the speed of the motors
		        gCurrentDutyCycle -= kDutyCycleIncrement;
		        if(gCurrentDutyCycle <= 0.0) {
		            gCurrentDutyCycle = 0.0;
		            // Change acceleration of motors
		            gDutyCycleIsIncreasing = true;
		        }       
		    }
		    // Read speed of the first motor for reference
		    // in controlling motor speed
		    speed = float(analogRead(0));
		    // Reset state
			lastTimeM1 = now;
		}
		else if(now - lastTimeM2 > 1 && swap == true) {
			// Start minute and hour hand motors in clockwise direction
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence1[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence2[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM2 = now;
		}
		else if(now - lastTimeM3 > 1 && swap == false) {
			// Start minute and hour hand motors in anti-clockwise direction
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence2[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence1[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM3 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 3;
	}
	else if (gHandGestureId == 4) {
		// Thumbs Down: Slows down mechanisms,
		// and turns clock hands anti-clockwise for trash kit
		unsigned int now = millis();
		if(now - lastTime1 > 200 && audiopause1 == false) {
			// Play first sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause1 = true;
		}
		else if(now - lastTime2 > 1000 && audiopause2 == false) {
			// Play second sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause2 = true;
		}
		else if(now - lastTime3 > 1400 && audiopause3 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause3 = true;
		}
		else if(now - lastTime4 > 2200 && audiopause4 == false) {
			// Play fourth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause4 = true;
		}
		else if(now - lastTime5 > 2600 && audiopause5 == false) {
			// Play fifth sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause5 = true;
		}
		else if(now - lastTime6 > 3200 && audiopause6 == false) {
			// Play sixth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause6 = true;
		}
		else if(now - lastTime7 > 3600 && audiopause7 == false) {
			// Play seventh sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause7 = true;
		}
		else if(now - lastTime8 > 4400 && audiopause7 == false) {
			// Play eighth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause8 = true;
		}
		else if(now - lastTime9 > 4600 && audiopause1 == true) {
			// Play ninth sound & reset sound sequence
			lastTime9 = now;
			lastTime8 = now;
			lastTime7 = now;
			lastTime6 = now;
			lastTime5 = now;
			lastTime4 = now;
			lastTime3 = now;
			lastTime2 = now;
			lastTime1 = now;
			// Resets pauses for sounds
			audiopause1 = false;
			audiopause2 = false;
			audiopause3 = false;
			audiopause4 = false;
			audiopause5 = false;
			audiopause6 = false;
			audiopause7 = false;
		}
		else if(now - lastTimeM1 > 1) {
			// Start Right-hand can motor
			kMotorState = !kMotorState;
			pwmWrite(kMotorPin1, 0.7);
			digitalWrite(kMotorPin2, kMotorState);
			// Start Left-hand can motor
			tMotorState = !tMotorState;
			pwmWrite(tMotorPin1, 0.7);
			digitalWrite(tMotorPin2, tMotorState);
			// Start Shoe motor
			sMotorState = !sMotorState;
			pwmWrite(sMotorPin1, 0.7);
			digitalWrite(sMotorPin2, sMotorState);
			// Start minute and hour hand motors
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence2[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence1[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 2) % 8;
			currentStep2 = (currentStep2 + 2) % 8;
			// Reset state
			lastTimeM1 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 4;
	}
	else if (gHandGestureId == 5) {
		// Thumbs Up: Speeds up mechanisms,
		// and turns clock hands clockwise for trash kit
		unsigned int now = millis();
		if(now - lastTime1 > 50 && audiopause1 == false) {
			// Play first sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause1 = true;
		}
		else if(now - lastTime2 > 250 && audiopause2 == false) {
			// Play second sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause2 = true;
		}
		else if(now - lastTime3 > 350 && audiopause3 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause3 = true;
		}
		else if(now - lastTime4 > 550 && audiopause4 == false) {
			// Play fourth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause4 = true;
		}
		else if(now - lastTime5 > 625 && audiopause5 == false) {
			// Play fifth sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause5 = true;
		}
		else if(now - lastTime6 > 800 && audiopause6 == false) {
			// Play sixth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause6 = true;
		}
		else if(now - lastTime7 > 900 && audiopause7 == false) {
			// Play seventh sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause7 = true;
		}
		else if(now - lastTime8 > 1100 && audiopause7 == false) {
			// Play eighth sound in sequence
			pdSendMessage("playSound", 2);
			// Pauses sound
			audiopause8 = true;
		}
		else if(now - lastTime9 > 1150 && audiopause1 == true) {
			// Play sixth sound & reset sound sequence
			lastTime9 = now;
			lastTime8 = now;
			lastTime7 = now;
			lastTime6 = now;
			lastTime5 = now;
			lastTime4 = now;
			lastTime3 = now;
			lastTime2 = now;
			lastTime1 = now;
			// Resets pauses for sounds
			audiopause1 = false;
			audiopause2 = false;
			audiopause3 = false;
			audiopause4 = false;
			audiopause5 = false;
			audiopause6 = false;
			audiopause7 = false;
		}
		else if(now - lastTimeM1 > 1) {
			// Start Right-hand can motor
			kMotorState = !kMotorState;
			pwmWrite(kMotorPin1, 1);
			digitalWrite(kMotorPin2, kMotorState);
			// Start Left-hand can motor
			tMotorState = !tMotorState;
			pwmWrite(tMotorPin1, 1);
			digitalWrite(tMotorPin2, tMotorState);
			// Start Shoe motor
			sMotorState = !sMotorState;
			pwmWrite(sMotorPin1, 1);
			digitalWrite(sMotorPin2, sMotorState);
			// Start minute and hour hand motors
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence1[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence2[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM1 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 5;
	}
	else if (gHandGestureId == 6) {
		// Peace Sign: Mimics beat of the popular song 'We Will Rock You' by Queen,
		// where the hands of the clock will rapidly move back and forth in opposite directions,
		// while the shoe kicks in sync with clock hands
		unsigned int now = millis();
		if(now - lastTime1 > 500 && audiopause1 == false) {
			// Play first sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause1 = true;
		}
		if(now - lastTime2 > 850 && audiopause2 == false) {
			// Play second sound in sequence
			pdSendMessage("playSound", 4);
			// Pauses sound
			audiopause2 = true;
		}
		if(now - lastTime3 > 1300 && audiopause3 == false) {
			// Play third sound in sequence
			pdSendMessage("playSound", 3);
			// Pauses sound
			audiopause3 = true;
		}
		else if(now - lastTime4 > 1650 && audiopause1 == true) {
			// Play fourth sound & reset sound sequence
			lastTime4 = now;
			lastTime3 = now;
			lastTime2 = now;
			lastTime1 = now;
			// Resets pauses for sounds
			audiopause1 = false;
			audiopause2 = false;
			audiopause3 = false;
		}
		else if(now - lastTimeM1 > 1000) {
			// Stop Right-hand can motor
			kMotorState = !kMotorState;
			pwmWrite(kMotorPin1, 0);
			digitalWrite(kMotorPin2, kMotorState);
			// Stop Left-hand can motor
			tMotorState = !tMotorState;
			pwmWrite(tMotorPin1, 0);
			digitalWrite(tMotorPin2, tMotorState);
			// Start Shoe motor
			sMotorState = !sMotorState;
			pwmWrite(sMotorPin1, 0.7);
			digitalWrite(sMotorPin2, sMotorState);
			// Reset state
			lastTimeM1 = now;
			// Change direction of stepper motor
			swap =! swap;
		}
		else if(now - lastTimeM2 > 1 && swap == true) {
			// Start minute and hour hand motors
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence1[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence1[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM2 = now;
		}
		else if(now - lastTimeM3 > 1 && swap == false) {
			// Start minute and hour hand motors
			for (int i = 0; i < 4; i++) {
		    digitalWrite(motorPins1[i], stepSequence2[currentStep1][i]);
		    digitalWrite(motorPins2[i], stepSequence2[currentStep2][i]);
			}
			// Move to the next step
			currentStep1 = (currentStep1 + 1) % 8;
			currentStep2 = (currentStep2 + 1) % 8;
			// Reset state
			lastTimeM3 = now;
		}
		// Prevents inaccuracies in gesture recognition
		// from disrupting flow of signal between Python logic
		// and C++ logic on Bela
		prevgHandGestureId = 6;
	}
	else if (gHandGestureId == 7) {
		// Lack of documentation from Google Gesture Recognizer model,
		// so 'ILoveYou' hand gesture (ID = 7) is unknown.
		// Thus, if detected by mistake, 
		// it will change state to 'Peace Sign' state (ID = 6)
		gHandGestureId = 6;
	}
	else if (gHandGestureId == 8) {
		// If unknown hand gesture is detected,
		// sets the current state to the previously read state,
		// to prevent disruptions in signal between code logics
		gHandGestureId = prevgHandGestureId;
	}
}
